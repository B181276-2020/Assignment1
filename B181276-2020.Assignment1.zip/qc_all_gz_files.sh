#!/usr/bin/bash
#This is a script to automatically apply the fastqc function to all raw data files in this folder as long as they end in .gz
#cd /localdisk/data/BPSM/Assignment1/fastq/
cd ../Assignment_final/quality_control_data

find . /localdisk/data/BPSM/Assignment1/fastq/ -name "*.fq.gz"  | parallel fastqc {} -o "~/Assignment1/Assignment_final/quality_control_data/"

cd ../../my_scripts

#It finds all fq.gz files and then runs the results into a fastqc that outputs inot the quality_control_data directory

#print 'This script is complete.'
