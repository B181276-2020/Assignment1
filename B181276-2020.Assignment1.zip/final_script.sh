#!/bin/bash
#This script sets up a set of directories to organise the data
#The script should start from the my_scripts directory
cd ..
mkdir Assignment_final
cd Assignment_final
mkdir quality_control_data
mkdir Slender
mkdir Stumpy
mkdir Tbb_genome_index 
mkdir count_data
cd quality_control_data
mkdir contents_of_zip_files
cd ../../my_scripts


#Made sure each script ends in the "my_script" directory again
#Running each script:
#1. fastq all fq.gz files.
./qc_all_gz_files.sh
#2. unzip all the fastqc files.
./unzipper.sh
#3. script that opens any HTML file you want.
#./what_file_do_you_want.sh
#4. Script that goes into each fastqc file and gets a summary file.
./get_summaries.sh
#5. Bowtie2 the pairs of alignments to the Tbbgene.bed.
./bowtie2_pairs_script.sh
#6. convert all resulting sam files to bam files.
./sam_to_bam.sh
#7. directory organiser to get all the files into the right directories.
./directory_organiser_slender_stumpy.sh
#8. bedtools multicov script that generates count data by indexing, sorting and then multicov'ing the .bam files in each Slender or Stumpy directory.
./bedtools_script.sh
#9. generates mean averages for each gene. 
./count_data_each_alignment.sh

#OTHER SCRIPTS:
#see "unused_scripts directory




