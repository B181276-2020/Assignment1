#!/bin/bash

#while reading the fqfile, it checks if slender or stumpy then bowties the two files and outputs it to either Slender or Stumpy
#Make sure this starts in the light location. Needs to start in Assignment_final (home)
cd ../Assignment_final
location=$(pwd)
echo $location
#First, copy over fasta file and index genome of Tbb using: 
#bowtie2-build [options]* <reference_in> <bt2_base>

cp /localdisk/data/BPSM/Assignment1/Tbb_genome/Tb927_genome.fasta.gz $location/Tbb_genome_index

#Unzip the fasta-gz file so bowtie2-build can read it

cd Tbb_genome_index
gunzip Tb927_genome.fasta.gz 
bowtie2-build -f Tb927_genome.fasta Tbb_genome


#While loop that bowties each of the two files and outputs them to the directory


while read ID name file1 file2;
do
if [ $name = "Slender" ];
then
bowtie2 -x Tbb_genome -1 ${file1} -2 ${file2} -S ${ID}_alignment_Slender.sam --no-mixed --no-unal -p 10
else [ $name = "Stumpy" ];
bowtie2 -x Tbb_genome -1 ${file1} -2 ${file2} -S ${ID}_alignment_Stumpy.sam --no-mixed --no-unal -p 10
fi
done < /localdisk/data/BPSM/Assignment1/fastq/fqfiles

#The option -S outputs a SAM file
#The -q flag means that the files are fasta format

#While loop that moves the files back to their directories.

rm -f all_sam_files.txt #housekeeping
find . -name "*sam" | cat > all_sam_files.txt
while read name
do
if [ $name = "*Slender.sam" ]
then
mv $name ../Slender
else [ $name = "*Stumpy.sam" ]
mv $name ../Stumpy
done < all_sam_files.txt

rm -f all_sam_files.txt #housekeeping

cd ../my_scripts
