#!/bin/bash
#First, to the correct directory

cd ../Assignment_final/Tbb_genome_index

#Remove all previous bam files
rm -f bam_slenders_stumpys.txt #house keeping
find . -name "*_Slender\.bam" >> bam_slenders_stumpys.txt
find . -name "*_Stumpy\.bam" >> bam_slenders_stumpys.txt
#While loop that removes all bams

while read bams
do
rm -f "${bams}" ;
done < bam_slenders_stumpys.txt
cat bam_slenders_stumpys.txt
rm -f bam_slenders_stumpys.txt #house keeping

#Then list all sam files
rm -f samfiles.txt #house keeping
find . -name "*_Slender\.sam" >> slenderfiles.txt
find . -name "*_Stumpy\.sam" >> stumpyfiles.txt
cat slenderfiles.txt
cat stumpyfiles.txt

#Script that gets all slender suffix files and makes them into bam files
while read slenderfile
do
samtools view -S -b "${slenderfile}" > "${slenderfile:2:3}"_alignment_Slender.bam ;
echo "This worked - slender"
done < slenderfiles.txt

#Script that gets all stumpy suffix files and makes them into bam files
while read stumpyfile
do
samtools view -S -b "${stumpyfile}" > "${stumpyfile:2:3}"_alignment_Stumpy.bam ;
echo "This worked - stumpy"
done < stumpyfiles.txt

rm -f slenderfiles.txt #house keeping 
rm -f stumpyfiles.txt #house keeping 


cd ../../my_scripts


