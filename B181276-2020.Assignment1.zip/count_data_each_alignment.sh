#!/bin/bash
#First, copy over the count files to the count_data directory 
cd ../Assignment_final/Slender
cp -t ../count_data count_data_slender.txt 
cd ../Stumpy
cp -t ../count_data count_data_stumpy.txt
cd ../count_data

#lets grab all the needed data and put it in a file:
#First Slender 

rm -f slender_all_counts.txt #housekeeping
while read chrom chromstart chromend genename gene plusorminus #first second third
do
echo -e "${genename}\t${first}\t${second}\t${third}" >> slender_all_counts.txt
done < count_data_slender.txt
#cat slender_all_counts.txt

#Now stumpy: 

rm -f stumpy_all_counts.txt #housekeeping
while read chrom chromstart chromend genename gene plusorminus first second third
do
echo -e "${genename}\t${first}\t${second}\t${third}" >> stumpy_all_counts.txt
done < count_data_stumpy.txt
#cat stumpy_all_counts.txt

# ONLY COUNTS SLENDER so that the awk run doesnt screw up
rm -f slender_counts_only.txt #house keeping
while read chrom chromstart chromend genename gene plusorminus first second third
do
echo -e "${first}\t${second}\t${third}" >> slender_counts_only.txt
done < count_data_slender.txt
#cat slender_counts_only.txt

# ONLY COUNTS STUMPY so that the awk run doesnt screw up
rm -f stumpy_counts_only.txt #house keeping
while read chrom chromstart chromend genename gene plusorminus first second third
do
echo -e "${first}\t${second}\t${third}" >> stumpy_counts_only.txt
done < count_data_stumpy.txt
cat stumpy_counts_only.txt


#first slender averages (using awk)
awk '{s=0; for (i=1;i<=NF;i++)s+=$i; print s/NF;}' slender_counts_only.txt | cat > slender_all_averages.txt
#cat slender_all_averages.txt 

#now stumpy averages (using awk)
awk '{s=0; for (i=1;i<=NF;i++)s+=$i; print s/NF;}' stumpy_counts_only.txt | cat > stumpy_all_averages.txt
#cat stumpy_all_averages.txt 

rm -f gene_names.txt #house keeping
# gets all gene names and puts them in a file. 
while read genename first second third
do  #Reads the "all_counts" slender file
 echo -e "${genename}" >> gene_names.txt
done < slender_all_counts.txt

#cat gene_names.txt
rm -f final_summary.txt # house keeping
paste gene_names.txt slender_all_averages.txt stumpy_all_averages.txt | column -s $'\t' -t | cat > pre_final_summary.txt
echo -e "gene_name\tslender_average\tstumpy_average" | cat - pre_final_summary.txt > final_summary.txt

cat final_summary.txt
head -1 final_summary.txt

rm -f pre_final_summary.txt # house keeping
rm -f slender_all_averages.txt # house keeping
rm -f stumpy_all_averages.txt # house keeping
rm -f gene_names.txt # house keeping
rm -f slender_all_counts.txt # house keeping 
rm -f stumpy_all_counts.txt # house keeping
rm -f stumpy_counts_only.txt #house keeping
rm -f slender_counts_only.txt #house keeping


