#!/usr/bin/bash


#Removes all lists generated from previous run of this program
cd ../Assignment_final
rm -f all_slenders.txt #housekeeping
rm -f all_stumpys.txt #housekeeping

#create a while loop to read fqfiles, see if we can output all files of the given prefix. Saves them to a list each

while read prefix name fqfile1 fqfile2
do
FS="\t";
if [ $name = "Slender" ] ; 
 then
 find /localdisk/data/BPSM/Assignment1/fastq -type f -maxdepth 1 -name "${prefix}_*" >> all_slenders.txt

#This finds all files in the fastq directory with the given prefix and moves it to slender
 else [ $name = "Stumpy" ] ; 
  find /localdisk/data/BPSM/Assignment1/fastq -type f -maxdepth 1 -name "${prefix}_*" >> all_stumpys.txt
fi
done < /localdisk/data/BPSM/Assignment1/fastq/fqfiles

#While loops that read the list of slenders and stumpys and then cp the files to their directories

while read slenders
do 
cp "$slenders" $PWD/Slender
cp "$slenders" $PWD/Tbb_genome_index
done <all_slenders.txt

while read stumpys
do 
cp "$stumpys" $PWD/Stumpy
cp "$stumpys" $PWD/Tbb_genome_index
done <all_stumpys.txt

rm -f all_slenders.txt #house keeping
rm -f all_stumpys.txt #house keeping

cd ../my_scripts


