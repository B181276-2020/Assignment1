#!/usr/bin/bash

#First we have to get into the directory we want:
cd ../Assignment_final/quality_control_data/contents_of_zip_files
find . -name "*_fastqc" | sort | uniq | cat > unfinished-all-fastqc-files.txt ;
rm -f all_fastqc_files.txt ; #housekeeping

#A while read loop that looks to fix the suffix of the file locations
while read fastqc_directory ;
do
echo ${fastqc_directory:2:15} >> all_fastqc_files.txt;
done < unfinished-all-fastqc-files.txt ;

rm -f unfinished-all-fastqc-files.txt; #housekeeping
#cat all_fastqc_files.txt
#pwd

rm -f report_of_warnings_and_fails.txt #housekeeping
rm -f report_of_all_warnings_and_fails.txt #housekeeping
#A while loop to grab the WARN and FAILS from each summary file
while read fqc_directory;
do
cd "$fqc_directory"
#This line goes to the directory in the list
egrep "WARN" summary.txt >> ../../report_of_all_warnings_and_fails.txt ;
egrep "FAIL" summary.txt >> ../../report_of_all_warnings_and_fails.txt ;
#These egreps take all lines with WARN and FAIL in them and add them to the report. The report is then outputed.
cd ..
done < all_fastqc_files.txt
cd .. 
cat report_of_all_warnings_and_fails.txt| sort -k3 | uniq > fastq_quality_assessment.txt ;
rm -f report_of_all_warnings_and_fails.txt
clear
cat fastq_quality_assessment.txt

cd ../../my_scripts






