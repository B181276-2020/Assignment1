#!/bin/bash
#First, we need to be in the right directory
cd ../Assignment_final/Tbb_genome_index
# Copy all slenders to slender directory and all stumpys to stumpy directory 

#For slender
find . -name "*Slender*" | sort | cat > slenfiles.txt
while read slenders
do 
cp "$slenders" $PWD/../Slender ;
done <slenfiles.txt

#For stumpy
find . -name "*Stumpy*" | sort | cat > stumfiles.txt
while read stumpys
do 
cp "$stumpys" $PWD/../Stumpy ;
done <stumfiles.txt


echo "Files copied to respective directories:"
cat slenfiles.txt
cat stumfiles.txt
rm -f slenfiles.txt
rm -f stumfiles.txt
echo "These are the directories:"
echo "Slender:"
cd ../Slender
ls
echo "Stumpy."
cd ../Stumpy
ls

#We need all the .bam files:

#First slender:
cd ../Slender
find . -name "*_Slender\.bam" > bam_slenders.txt
echo "processing:"
cat bam_slenders.txt

#Sort and index slender: 
while read bam_slenders
do
echo "processing : ${bam_slenders:2:3}"
samtools sort "${bam_slenders:2:40}" -o "${bam_slenders:2:3}_sorted.bam" 
samtools index "${bam_slenders:2:3}_sorted.bam" 
done < bam_slenders.txt
rm -f bam_slenders.txt #housekeeping



#Now stumpy: 
cd ../Stumpy
find . -name "*_Stumpy\.bam" > bam_stumpy.txt
echo "processing:"
cat bam_stumpy.txt

#Sort and index stumy:
while read bam_stumpy
do
echo "processing : ${bam_stumpy:2:3}"
samtools sort "${bam_stumpy:2:40}" -o "${bam_stumpy:2:3}_sorted.bam" 
samtools index "${bam_stumpy:2:3}_sorted.bam" 
done < bam_stumpy.txt
rm -f bam_stumpy.txt #housekeeping

#Lets bedtool multicov slender
cd ../Slender

multicov_elements=(*_sorted.bam)
echo "processing :"
echo ${multicov_elements[@]}

#while read that bedtool multicov the array
while read bam1 bam2 bam3 
do
bedtools multicov -bams $bam1 $bam2 $bam3 -bed /localdisk/data/BPSM/Assignment1/Tbbgenes.bed > count_data_slender.txt
echo "$bam1 $bam2 $bam3 were processed."
done <<< ${multicov_elements[*]}
echo "Script for multicov Slender samples is done."


#Lets bedtool multicov stumpy

cd ../Stumpy
multicov_elements_stumpy=(*_sorted.bam)
echo "processing :"
echo ${multicov_elements_stumpy[@]}

#while read bedtool multicov the array 

while read bam1 bam2 bam3 
do
bedtools multicov -D -bams $bam1 $bam2 $bam3 -bed /localdisk/data/BPSM/Assignment1/Tbbgenes.bed > count_data_stumpy.txt
echo "$bam1 $bam2 $bam3 were processed."
done <<< ${multicov_elements_stumpy[*]}
echo "Script for multicov Stumpy samples is done."


echo "This script is complete"

cd ../../my_scripts

