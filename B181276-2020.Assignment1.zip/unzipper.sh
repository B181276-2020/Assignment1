#!/usr/bin/bash
cd ../Assignment_final/quality_control_data

find . -name "*fastqc.zip" | sort | cut -d "/" -f 2- >zip_file_names.txt
#This line finds all zip files, sorts them then cuts the file name out (starts with ./, causing error, the cut sorts this out
while read zipname ;
do 
unzip -o -q $zipname -d contents_of_zip_files ;
done <zip_file_names.txt
rm -f zip_file_names.tx # house keeping

cd ../../my_scripts
#This unzips all the files into the quality_control_data file. 
#The -o flag stops it from prompting "Do you want to extract/overwrite this?"
#The -q flag stops it from spitting out text
#The -d flag determines the directory


